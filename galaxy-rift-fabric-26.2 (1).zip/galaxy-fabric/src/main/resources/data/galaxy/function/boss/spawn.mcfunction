summon galaxy:galaxy_warden ~20 ~ ~ {PersistenceRequired:1b}
tellraw @a[distance=..200] {"text":"The Galaxy Warden awakens...","color":"dark_purple"}
