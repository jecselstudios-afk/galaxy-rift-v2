execute unless block ~ ~ ~ galaxy:rift_core run kill @s
scoreboard players add @s galaxy_t 1
function galaxy:ritual/beam
execute if score @s galaxy_t matches 1 run playsound minecraft:block.beacon.activate block @a ~ ~ ~ 6 0.5
execute if score @s galaxy_t matches 1 run forceload add ~ ~
execute if score @s galaxy_t matches 1 in galaxy:starfall run forceload add 0 0
execute if score @s galaxy_t matches 60 run playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 12 0.6
execute if score @s galaxy_t matches 100 run playsound minecraft:entity.lightning_bolt.thunder weather @a ~ ~ ~ 12 0.5
execute if score @s galaxy_t matches 100 run advancement grant @a[distance=..96] only galaxy:sky_breaks
execute if score @s galaxy_t matches 40.. run function galaxy:ritual/crack_gate
execute if score @s galaxy_t matches 100..259 run effect give @e[distance=..64,type=!minecraft:marker] minecraft:levitation 2 2 true
execute if score @s galaxy_t matches 100..259 as @e[distance=..64,type=!minecraft:marker,type=!minecraft:player] at @s facing entity @e[type=minecraft:marker,tag=galaxy_ritual,limit=1,sort=nearest] feet run tp @s ^ ^0.12 ^0.25
execute if score @s galaxy_t matches 200 in galaxy:starfall run function galaxy:warp/build_ship
execute if score @s galaxy_t matches 260.. run function galaxy:ritual/finish
