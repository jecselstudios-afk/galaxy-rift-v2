give @s galaxy:rift_core 1
tellraw @a {"text":"The dragon's death tears a fragment from the sky...","color":"dark_purple"}
advancement revoke @s only galaxy:dragon_kill
