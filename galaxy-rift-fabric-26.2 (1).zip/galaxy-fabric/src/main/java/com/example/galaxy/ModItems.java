package com.example.galaxy;

import java.util.Map;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.block.Block;

public class ModItems {
	public static final TagKey<Block> INCORRECT_FOR_STARFORGED_TOOL =
			TagKey.create(Registries.BLOCK, GalaxyMod.id("incorrect_for_starforged_tool"));
	public static final TagKey<Item> REPAIRS_STARFORGED =
			TagKey.create(BuiltInRegistries.ITEM.key(), GalaxyMod.id("repairs_starforged"));

	public static final ToolMaterial STARFORGED_TOOLS = new ToolMaterial(
			INCORRECT_FOR_STARFORGED_TOOL, 4000, 14.0F, 6.0F, 30, REPAIRS_STARFORGED);

	public static final ResourceKey<EquipmentAsset> STARFORGED_ASSET =
			ResourceKey.create(EquipmentAssets.ROOT_ID, GalaxyMod.id("starforged"));

	public static final ArmorMaterial STARFORGED_ARMOR = new ArmorMaterial(
			55,
			Map.of(ArmorType.HELMET, 4, ArmorType.CHESTPLATE, 10, ArmorType.LEGGINGS, 8, ArmorType.BOOTS, 4),
			30,
			SoundEvents.ARMOR_EQUIP_NETHERITE,
			6.0F,
			0.3F,
			REPAIRS_STARFORGED,
			STARFORGED_ASSET);

	private static Item.Properties epic() {
		return new Item.Properties().rarity(Rarity.EPIC);
	}

	private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, GalaxyMod.id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
	}

	public static final Item INGOT = register("starforged_ingot", Item::new, epic());
	public static final Item SWORD = register("starforged_sword", Item::new, epic().sword(STARFORGED_TOOLS, 3.0F, -2.4F));
	public static final Item PICKAXE = register("starforged_pickaxe", Item::new, epic().pickaxe(STARFORGED_TOOLS, 1.0F, -2.8F));
	public static final Item HELMET = register("starforged_helmet", Item::new, epic().humanoidArmor(STARFORGED_ARMOR, ArmorType.HELMET));
	public static final Item CHESTPLATE = register("starforged_chestplate", Item::new, epic().humanoidArmor(STARFORGED_ARMOR, ArmorType.CHESTPLATE));
	public static final Item LEGGINGS = register("starforged_leggings", Item::new, epic().humanoidArmor(STARFORGED_ARMOR, ArmorType.LEGGINGS));
	public static final Item BOOTS = register("starforged_boots", Item::new, epic().humanoidArmor(STARFORGED_ARMOR, ArmorType.BOOTS));

	public static final Item STALKER_EGG = register("void_stalker_spawn_egg", SpawnEggItem::new,
			new Item.Properties().spawnEgg(ModEntities.VOID_STALKER));
	public static final Item WARDEN_EGG = register("galaxy_warden_spawn_egg", SpawnEggItem::new,
			new Item.Properties().spawnEgg(ModEntities.GALAXY_WARDEN));

	public static void init() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(tab -> tab.accept(INGOT));
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(tab -> tab.accept(ModBlocks.RIFT_CORE_ITEM));
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
			tab.accept(PICKAXE);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
			tab.accept(SWORD);
			tab.accept(HELMET);
			tab.accept(CHESTPLATE);
			tab.accept(LEGGINGS);
			tab.accept(BOOTS);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS).register(tab -> {
			tab.accept(STALKER_EGG);
			tab.accept(WARDEN_EGG);
		});
	}
}
