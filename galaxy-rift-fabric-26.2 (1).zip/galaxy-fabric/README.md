# Galaxy Rift (Fabric, Minecraft 26.2)

Beat the Ender Dragon -> get a Rift Core -> light it (redstone / 4 obsidian sides / flint & steel)
-> beam + cracked sky + everything floats up -> spaceship warp -> Starfall dimension with stronger
mobs, a boss (Galaxy Warden), Starforged tools + armor, and 6 advancements.

## Get the jar (no PC needed)
1. Create a new GitHub repo and upload everything in this folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab -> the "build" workflow runs automatically (or press "Run workflow").
3. When it's green, open the run and download the **galaxy-rift-jar** artifact. Use `galaxy-rift-0.1.0.jar` (not -sources).
4. Put it in `mods/` with Fabric Loader 0.19.5+, Fabric API 0.161.0+26.2, Java 25.

If the build is red, open the failed step and send me the red error lines.

## Local build
`./gradlew build` (JDK 25) -> `build/libs/`.

## Test commands
/give @s galaxy:rift_core
/give @s galaxy:starforged_ingot 64
/summon galaxy:galaxy_warden
