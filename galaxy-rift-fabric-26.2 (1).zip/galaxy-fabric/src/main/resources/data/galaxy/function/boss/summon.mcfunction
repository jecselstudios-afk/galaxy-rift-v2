summon galaxy:void_stalker ~4 ~ ~3
summon galaxy:void_stalker ~-4 ~ ~3
summon galaxy:void_stalker ~0 ~ ~-4
