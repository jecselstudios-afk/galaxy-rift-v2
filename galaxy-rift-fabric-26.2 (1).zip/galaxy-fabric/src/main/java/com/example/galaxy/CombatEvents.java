package com.example.galaxy;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class CombatEvents {
	public static void init() {
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (blocked) return;
			Entity attacker = source.getEntity();

			// Starforged Sword: withers + weakens + marks the target, heals the wielder.
			if (attacker instanceof LivingEntity wielder && wielder.getMainHandItem().is(ModItems.SWORD)) {
				entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
				entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
				entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
				wielder.heal(2.0F);
			}

			// Starfall mobs hit back with Wither + Darkness.
			if (attacker instanceof VoidStalker || attacker instanceof GalaxyWarden) {
				entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
				entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
			}
		});
	}
}
