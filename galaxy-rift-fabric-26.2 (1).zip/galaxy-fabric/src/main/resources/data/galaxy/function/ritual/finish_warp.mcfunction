tag @a[distance=..64] add galaxy_warp
execute as @a[tag=galaxy_warp] run function galaxy:warp/start
