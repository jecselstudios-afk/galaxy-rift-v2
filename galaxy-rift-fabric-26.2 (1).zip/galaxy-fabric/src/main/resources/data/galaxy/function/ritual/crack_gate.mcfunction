scoreboard players operation #m galaxy_t = @s galaxy_t
scoreboard players operation #m galaxy_t %= #3 galaxy_t
execute if score #m galaxy_t matches 0 run function galaxy:ritual/crack
