effect clear @s minecraft:speed
effect clear @s minecraft:resistance
effect give @s minecraft:slow_falling 8 0 true
execute in galaxy:starfall run spreadplayers 0 0 0 16 false @s
title @s times 10 60 20
title @s subtitle {"text":"Stronger mobs. Better loot."}
title @s title {"text":"STARFALL","color":"dark_purple"}
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 2 0.5
execute at @s unless entity @e[type=galaxy:galaxy_warden,distance=..500] run function galaxy:boss/spawn
