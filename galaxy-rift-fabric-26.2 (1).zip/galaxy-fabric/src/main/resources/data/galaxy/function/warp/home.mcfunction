effect give @s minecraft:slow_falling 8 0 true
execute in minecraft:overworld run spreadplayers 0 0 0 48 false @s
title @s title {"text":"HOME","color":"aqua"}
