effect give @e[distance=..64,type=!minecraft:marker,type=!minecraft:player] minecraft:slow_falling 15 0 true
execute if dimension galaxy:starfall run function galaxy:ritual/finish_home
execute unless dimension galaxy:starfall run function galaxy:ritual/finish_warp
particle minecraft:explosion_emitter ~ ~1 ~ 1 1 1 0 3 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 8 0.7
setblock ~ ~ ~ minecraft:air
kill @s
