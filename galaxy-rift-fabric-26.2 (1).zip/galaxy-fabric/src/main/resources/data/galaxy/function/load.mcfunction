scoreboard objectives add galaxy_t dummy
scoreboard objectives add galaxy_w dummy
scoreboard players set #3 galaxy_t 3
scoreboard players set #100 galaxy_t 100
scoreboard players set #160 galaxy_t 160
bossbar add galaxy:warden "Galaxy Warden"
bossbar set galaxy:warden color purple
bossbar set galaxy:warden style notched_10
bossbar set galaxy:warden max 500
